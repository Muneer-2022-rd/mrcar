part of 'lang_bloc.dart';

abstract class LangEvent extends Equatable {
  const LangEvent();

  @override
  List<Object> get props => [];
}

class GetCurrentLangEvent extends LangEvent {}

class LangChangedEvent extends LangEvent {
  final String languageCode;
  const LangChangedEvent({
    required this.languageCode,
  });
  @override
  List<Object> get props => [languageCode];
}
