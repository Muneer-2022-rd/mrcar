part of 'lang_bloc.dart';

abstract class LangState extends Equatable {
  const LangState();

  @override
  List<Object> get props => [];
}

class LangInitial extends LangState {}

class LoadedLangState extends LangState {
  final Locale locale;
  const LoadedLangState({
    required this.locale,
  });

  @override
  List<Object> get props => [locale];
}
