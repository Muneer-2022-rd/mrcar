import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../data/lang_data.dart';

part 'lang_event.dart';
part 'lang_state.dart';

class LangBloc extends Bloc<LangEvent, LangState> {
  final LanguageCacheHelper languageCacheHelper;
  LangBloc({required this.languageCacheHelper}) : super(LangInitial()) {
    on<LangEvent>((event, emit) async {
      if (event is GetCurrentLangEvent) {
        final String cachedLanguageCode =
            await languageCacheHelper.getCachedLanguageCode();
        emit(LoadedLangState(locale: Locale(cachedLanguageCode)));
      } else if (event is LangChangedEvent) {
        final languageCode = event.languageCode;
        await languageCacheHelper.cacheLanguageCode(languageCode);
        emit(LoadedLangState(locale: Locale(languageCode)));
      }
    });
  }
}
